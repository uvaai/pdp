import sys, string

##############
# Assignment 1
##############

def read_stopwords():
    with open("stopwords.txt") as f:
        stopwords = [s.strip() for s in f.readlines()]
        # Assignment 1A
        pass

def filter_word(word, stopwords):
    # Assignment 1B
    pass


##############
# Assignment 2
##############

def build_index(filename, stopwords):
    # Assignment 2A
    pass

def search_index(word, book_index):
    # Assignment 2B
    pass

def show_search_results(line_numbers):
    # Assignment 2C
    pass


###############
# Staring code
###############

def convert_word(s):
    return s.strip(string.punctuation + string.whitespace + \
        string.digits).lower()

def read_gutenberg_file(filename, stopwords):
    processed_words = []
    with open(filename) as f:
        started = False
        for i, line in enumerate(f.readlines()): 
            if line[:9] == "*** START":
                started = True
            elif line[:7] == "*** END":
                break
            
            elif started: 
                line_number = i+1
                for s in line.split():
                    word = convert_word(s)
                    if not filter_word(word, stopwords):
                        processed_words.append((word, line_number))
    
    return processed_words

def user_input_search(book_index):
    for line in sys.stdin:
        searched_word = convert_word(line)
        line_numbers = search_index(searched_word, book_index)        
        show_search_results(line_numbers)

if __name__ == "__main__":
    stopwords = read_stopwords()

    try:
        if len(sys.argv) == 1:
            print("No arguments provided.", \
                    "Please specifiy the file you want to search.")
            raise KeyboardInterrupt 
        
        book_index = build_index(sys.argv[1], stopwords)
        
        print("Index built for", sys.argv[1]+".",
                "Type the word you want to look up.")
        
        user_input_search(book_index)         
    
    except KeyboardInterrupt:
        print("\nQuitting the program.")
        sys.exit()

