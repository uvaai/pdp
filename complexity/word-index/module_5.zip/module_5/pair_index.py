import sys, string

###############
# Old functions
###############

def read_stopwords():
    # Your previous solution goes here
    pass

def filter_word(word, stopwords):
    # Your previous solution goes here
    pass

def show_search_results(line_numbers):
    # Your previous solution goes here
    pass


###############
# Assignment 3
###############

def build_pair_index(filename, stopwords, recency_size=5):
    # Assignment 3A
    pass

def search_pair_index(word_1, word_2, book_index):
    # Assignment 3A
    pass


###############
# Staring code
###############

def convert_word(s):
    return s.strip(string.punctuation + string.whitespace + \
        string.digits).lower()

def read_gutenberg_file(filename, stopwords):
    processed_words = []
    with open(filename) as f:
        started = False
        for i, line in enumerate(f.readlines()): 
            if line[:9] == "*** START":
                started = True
            elif line[:7] == "*** END":
                break
            
            elif started: 
                line_number = i+1
                for s in line.split():
                    word = convert_word(s)
                    if not filter_word(word, stopwords):
                        processed_words.append((word, line_number))
    
    return processed_words

def user_input_pair_search(book_index):
    for line in sys.stdin:
        words = [convert_word(s) for s in line.split()] 
        line_numbers = search_pair_index(words[0], words[1], book_index)        
        show_search_results(line_numbers)

if __name__ == "__main__":
    stopwords = read_stopwords()

    try:
        if len(sys.argv) == 1:
            print("No arguments provided.", \
                    "Please specifiy the file you want to search.")
            raise KeyboardInterrupt 
        
        book_index = build_pair_index(sys.argv[1], stopwords)
        
        print("Index built for", sys.argv[1]+".",
                "Type the word you want to look up.")
        
        user_input_pair_search(book_index)         
    
    except KeyboardInterrupt:
        print("\nQuitting the program.")
        sys.exit()

